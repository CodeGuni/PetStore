﻿namespace PetStoreHimanshu_9017107.Models
{
    public class FeaturedProduct
    {
        public string Name { get; set; }
        public double Price { get; set; }
        public string Image { get; set; }
    }
}
