using Microsoft.AspNetCore.Mvc;
using PetStoreHimanshu_9017107.Models;

namespace PetStoreHimanshu_9017107.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            var products = new List<FeaturedProduct>
    {
        new FeaturedProduct { Name="Diamond Naturals Dog Food", Price=59.99, Image="dog1.jpg" },
        new FeaturedProduct { Name="Holistic Cat Blend", Price=45.50, Image="cat1.jpg" },
        new FeaturedProduct { Name="Durable Chew Toy", Price=14.99, Image="toy1.jpg" },
    };

            return View(products);
        }

    }
}
